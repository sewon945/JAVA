package Qusetion3;

public class MP3Player {
	
	private String name;
	private String color;
	private boolean power;
	
	public MP3Player(String name, String color, boolean power) {
		super();
		this.name = name;
		this.color = color;
		this.power = power;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public boolean isPower() {
		return power;
	}

	public void setPower(boolean power) {
		this.power = power;
	}
	
	
	
	
	
	

}
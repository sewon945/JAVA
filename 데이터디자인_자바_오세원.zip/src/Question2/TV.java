package Question2;

public class TV {

	private String channle;
	private String color;
	
	
	
	public void Tv() {
		System.out.println("Tv의 현재 채널은 : " + channle + "이고," +"Tv의 색깔은 " + color +" 입니다.");
	}
	
	
	
	
	
	
}
